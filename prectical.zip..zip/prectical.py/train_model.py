import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import pickle

# Sample dataset for training
data = [
    # url_length, has_ip, count_dots, has_https, has_at, has_hyphen, count_slash, count_question, count_equal, suspicious_words, label
    [18, 0, 1, 1, 0, 0, 3, 0, 0, 0, 0],
    [25, 0, 2, 1, 0, 0, 3, 0, 0, 0, 0],
    [32, 0, 2, 1, 0, 1, 4, 0, 0, 1, 1],
    [65, 0, 4, 0, 1, 1, 7, 1, 2, 1, 1],
    [80, 1, 3, 0, 0, 1, 6, 1, 1, 1, 1],
    [15, 0, 1, 1, 0, 0, 2, 0, 0, 0, 0],
    [90, 1, 5, 0, 1, 1, 8, 1, 3, 1, 1],
    [28, 0, 2, 1, 0, 0, 3, 0, 0, 0, 0],
    [55, 0, 3, 0, 1, 1, 5, 1, 1, 1, 1],
    [22, 0, 1, 1, 0, 0, 3, 0, 0, 0, 0],
    [70, 1, 4, 0, 1, 1, 7, 1, 2, 1, 1],
    [30, 0, 2, 1, 0, 0, 4, 0, 0, 0, 0],
    [45, 0, 3, 1, 0, 1, 5, 0, 1, 1, 1],
    [20, 0, 1, 1, 0, 0, 2, 0, 0, 0, 0],
]

columns = [
    "url_length",
    "has_ip",
    "count_dots",
    "has_https",
    "has_at",
    "has_hyphen",
    "count_slash",
    "count_question",
    "count_equal",
    "suspicious_words",
    "label"
]

df = pd.DataFrame(data, columns=columns)

X = df.drop("label", axis=1)
y = df["label"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_scaled, y)

with open("phishing_model.pkl", "wb") as f:
    pickle.dump(model, f)

with open("scaler.pkl", "wb") as f:
    pickle.dump(scaler, f)

print("Model and scaler saved successfully.")
