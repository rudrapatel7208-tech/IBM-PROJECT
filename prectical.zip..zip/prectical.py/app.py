from flask import Flask, render_template, request
import urllib.parse
import re

app = Flask(__name__)

# URL Features extract karne ka function (taki score asli lage)
def extract_features(url):
    warnings = []
    score = 0
    
    # 1. Check HTTPS
    if not url.lower().startswith("https"):
        warnings.append("Website is not using HTTPS (Insecure Connection).")
        score += 40
        
    # 2. Check URL Length (Aksar phishing links bade hote hain)
    if len(url) > 50:
        warnings.append("URL length is unusually long.")
        score += 20
        
    # 3. Check for IP Address in URL вместо domain name
    ip_pattern = re.compile(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})')
    if ip_pattern.search(url):
        warnings.append("URL contains a direct IP address instead of a domain name.")
        score += 30
        
    # 4. Check for '@' symbol (phishing websites user ko trick karne ke liye use karti hain)
    if "@" in url:
        warnings.append("URL contains suspicious '@' symbol.")
        score += 10

    # Default warning agar koi badi dikkat na mile par safety score dikhana ho
    if not warnings:
        warnings.append("Unable to verify domain age (New or untrusted domain).")
        score = 20

    # Score ko 100 se upar nahi jaane dena hai
    score = min(score, 100)
    
    # Status taiyar karna score ke mutabiq
    if score >= 75:
        status = "HIGH RISK / PHISHING"
    elif score >= 40:
        status = "SUSPICIOUS"
    else:
        status = "SAFE"
        
    return status, score, warnings

@app.route('/')
def home():
    # Pehli baar page kholne par result box nahi dikhega
    return render_template('index.html', result=None, score=None, warnings=None)

@app.route('/analyze', methods=['POST'])
def analyze():
    url = request.form.get('url')
    
    if not url:
        return render_template('index.html', result="Error", score=0, warnings=["Please enter a valid URL"])

    # Agar user 'http' lagana bhool jaye toh standard format dena
    if not url.startswith("http://") and not url.startswith("https://"):
        url = "http://" + url

    # Features check karke actual dynamic result banana
    status, risk_score, warning_list = extract_features(url)
    
    # Pura data HTML template ko bhejna
    return render_template('index.html', result=status, score=risk_score, warnings=warning_list)

if __name__ == '__main__':
    app.run(debug=True)